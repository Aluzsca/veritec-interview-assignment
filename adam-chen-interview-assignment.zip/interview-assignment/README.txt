I'll start off by saying that I haven't used C# in many years so there's some things 
I've forgotten how to do. From here, I'll go through my design choices like the user input section.
Pretty basic stuff, ask the user to enter their salary and then the pay frequency.
To make the program a bit more user-friendly, I've made it so you aren't required to enter a capital letter
as a sort of error catcher. This is also the case for if the user inputs an invalid amount for their salary. 
Then the frequency part is just me setting up what the net income will need to be divided by. The 
super and taxable income is simple maths. From here, I'm not too proud of my work as I'm certain there's a 
much more eloquent way to do these conditions but it's the best I can come up withat the moment. 
I set up some conditions and what will be printed out for each of those conditions while also using the 
ceiling and round functions based on the requirements. This more or less covers the design decisions. 

I am aware of some features I've missed like in the case of someone putting in the wrong inputs, ideally the
program should produce an error message and ask for the fields again. I couldn't find the way to do so.
Also, the maths is off very slightly when compared to the example in the assignment. I believe it is 
a rounding issue somewhere but not sure exactly where. With that being said though, I feel that rounding 
should be done at the very end of the calculations and not during to reduce variance. 

In regards to being future-proof, it is fairly simple to change the income rules by just changing the 
percent values as they aren't set in stone. I've also added comments to make it easier to find where 
certain sections are.