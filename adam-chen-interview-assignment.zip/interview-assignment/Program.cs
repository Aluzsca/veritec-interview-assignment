﻿using System;
					
public class Program
{
	public static void Main()
	
	{
		Double packageAmount, super, netIncome;
		Double taxableIncome = 0.0;
		Double levyMedicare = 0.0;
		Double levyBudget = 0.0;
		Double incomeTax = 0.0;
		Double payPacket = 0.0;
		String frequency;
        int i = 0;
		//User Interaction
        Console.Write("Enter your salary package amount : ");
        packageAmount = Convert.ToInt32(Console.ReadLine());
		if (packageAmount < 0) {
				Console.Write("\nPlease enter a valid salary : ");
		}
        Console.Write("\nEnter your pay frequency (W for weekly, F for fortnightly, M for monthly): ");
		//Does not require case sensitivity
		frequency = Console.ReadLine().ToUpper();
		if (frequency == "W") {
			i = 52;
		}
		else if (frequency == "F") {
			i = 26;
		}
		else if (frequency == "M") {
			i = 12;
		}
		else {
				Console.Write("Please choose a valid pay frequency option");
		}
		
		//Super
        super = (packageAmount * 8.6758) / 100;
        taxableIncome = packageAmount - super;
		
		Console.Write("\n\nGross Package : $" + packageAmount);
		Console.Write("\nSuperannuation : $" + super);
		
		Console.Write("\n\nTaxable Income : $" + Math.Round(taxableIncome, 2));
		Math.Floor(taxableIncome);
		Console.Write("\n\nDeductions: ");
		//Medicare Levy
        // 0-21335
 		if (taxableIncome > 0 && taxableIncome <= 21335) {
				levyMedicare = 0;
			Console.Write("\nMedicare Levy: $" + Math.Ceiling(levyMedicare));
		}
        // 21336-26668
		else if (taxableIncome > 21335 && taxableIncome <= 26668) {
			levyMedicare = (packageAmount - 21335) * 0.1;
			Console.Write("\nMedicare Levy: $" + Math.Ceiling(levyMedicare));
		}
        // 26669+
		else if (taxableIncome > 26668) {
			levyMedicare = taxableIncome * 0.02;
			Console.Write("\nMedicare Levy: $" + Math.Ceiling(levyMedicare));
		}
		//Budget Repair Levy
        // 0-180000
		if (taxableIncome > 0 && taxableIncome <= 180000) {
			levyBudget = 0;
			Console.Write("\nBudget Repair Levy: $" + Math.Ceiling(levyBudget));
		}
        // 180000+
		else if (taxableIncome > 180000) {
			levyBudget = (taxableIncome - 180000) * 0.02;
			Console.Write("\nBudget Repair Levy: $" + Math.Ceiling(levyBudget));
		}
		//Income Tax
        // 0-18200
		if (taxableIncome > 0 && taxableIncome <= 18200) {
			incomeTax = 0;
			Console.Write("\nIncome Tax: $" + incomeTax);
		}
        // 18201-37000
		else if (taxableIncome > 18200 && taxableIncome <= 37000) {
			incomeTax = (taxableIncome - 18200) * 0.19;
			Console.Write("\nIncome Tax: $" + Math.Ceiling(incomeTax));
		}
        // 37001-87000
		else if (taxableIncome > 37000 && taxableIncome <= 87000) {
			incomeTax = ((taxableIncome - 37000) * 0.325) + 3572;
			Console.Write("\nIncome Tax: $" + Math.Ceiling(incomeTax));
		}
        // 87001-180000
		else if (taxableIncome > 87000 && taxableIncome <= 180000) {
			incomeTax = ((taxableIncome - 37000) * 0.37) + 19822;
			Console.Write("\nIncome Tax: $" + Math.Ceiling(incomeTax));
		}
        // 180001+
		else if (taxableIncome > 180000) {
			incomeTax = ((taxableIncome - 180000) * 0.47) + 54232;
			Console.Write("\nIncome Tax: $" + incomeTax);
		}
		netIncome = taxableIncome - levyMedicare - levyBudget - incomeTax;
		Console.Write("\n\nNet Income: $" + Math.Round(netIncome, 2));
		payPacket = netIncome / i;
		Console.Write("\nPay Packet: $" + Math.Round(payPacket, 2));
	}
}

